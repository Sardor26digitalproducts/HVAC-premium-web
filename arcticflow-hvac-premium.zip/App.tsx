
import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import Stats from './components/Stats';
import Services from './components/Services';
import WhyUs from './components/WhyUs';
import QuoteForm from './components/QuoteForm';
import Testimonials from './components/Testimonials';
import ServiceAreaMap from './components/ServiceAreaMap';
import Footer from './components/Footer';
import VoiceAssistant from './components/VoiceAssistant';

const App: React.FC = () => {
  return (
    <div className="min-h-screen selection:bg-blue-100">
      <Header />
      <main>
        <Hero />
        <Stats />
        <Services />
        <WhyUs />
        <QuoteForm />
        <Testimonials />
        <ServiceAreaMap />
      </main>
      <Footer />
      
      {/* Premium Gemini Voice Assistant */}
      <VoiceAssistant />
    </div>
  );
};

export default App;
