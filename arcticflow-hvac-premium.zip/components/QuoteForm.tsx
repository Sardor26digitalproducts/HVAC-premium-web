
import React, { useState } from 'react';

const QuoteForm: React.FC = () => {
  const [status, setStatus] = useState<'idle' | 'sending' | 'success'>('idle');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStatus('sending');
    setTimeout(() => setStatus('success'), 1500);
  };

  return (
    <section id="quote" className="py-32 bg-gray-50">
      <div className="max-w-4xl mx-auto px-6">
        <div className="bg-white rounded-[3rem] p-12 md:p-20 shadow-2xl shadow-gray-200 border border-gray-100">
          <div className="text-center mb-12">
            <h2 className="text-4xl md:text-6xl font-extrabold mb-6 tracking-tight">Quick Quote</h2>
            <p className="text-xl text-gray-500">We respond in 15 minutes or less during business hours.</p>
          </div>

          {status === 'success' ? (
            <div className="text-center py-20">
              <div className="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <svg className="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <h3 className="text-3xl font-bold mb-2">Request Received!</h3>
              <p className="text-gray-500">A specialist is reviewing your inquiry now.</p>
              <button 
                onClick={() => setStatus('idle')} 
                className="mt-8 text-[#0B5FFF] font-bold"
              >
                Send another request
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-8">
              <div className="grid md:grid-cols-2 gap-8">
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-widest text-gray-400">Full Name</label>
                  <input 
                    required
                    type="text" 
                    placeholder="John Doe" 
                    className="w-full bg-gray-50 border-0 rounded-2xl px-6 py-5 text-lg focus:ring-2 focus:ring-[#0B5FFF] transition-all outline-none" 
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-widest text-gray-400">Phone Number</label>
                  <input 
                    required
                    type="tel" 
                    placeholder="(602) 000-0000" 
                    className="w-full bg-gray-50 border-0 rounded-2xl px-6 py-5 text-lg focus:ring-2 focus:ring-[#0B5FFF] transition-all outline-none" 
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-bold uppercase tracking-widest text-gray-400">Service Type</label>
                <select className="w-full bg-gray-50 border-0 rounded-2xl px-6 py-5 text-lg focus:ring-2 focus:ring-[#0B5FFF] transition-all outline-none appearance-none cursor-pointer">
                  <option>AC Repair</option>
                  <option>Heating Repair</option>
                  <option>New System Install</option>
                  <option>Annual Maintenance</option>
                  <option>Emergency Service</option>
                </select>
              </div>

              <button 
                type="submit" 
                disabled={status === 'sending'}
                className="w-full bg-[#0B5FFF] text-white py-6 rounded-2xl text-xl font-bold hover:bg-blue-600 transition-all shadow-xl shadow-blue-500/30 disabled:opacity-50 active:scale-95"
              >
                {status === 'sending' ? 'Sending...' : 'Request Instant Quote'}
              </button>
              
              <p className="text-center text-sm text-gray-400 font-medium">
                No strings attached. Your privacy is protected.
              </p>
            </form>
          )}
        </div>
      </div>
    </section>
  );
};

export default QuoteForm;
