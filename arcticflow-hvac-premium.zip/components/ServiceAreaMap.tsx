
import React from 'react';

const ServiceAreaMap: React.FC = () => {
  return (
    <section className="py-32 bg-gray-50 border-t border-gray-100 overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-20 items-center">
          <div>
            <h2 className="text-5xl font-extrabold tracking-tight mb-8">Serving all of Phoenix & surrounding areas.</h2>
            <div className="grid grid-cols-2 gap-4">
              {['Scottsdale', 'Tempe', 'Mesa', 'Chandler', 'Gilbert', 'Glendale', 'Peoria', 'Paradise Valley'].map((city) => (
                <div key={city} className="flex items-center gap-2 text-gray-500 font-medium">
                  <span className="w-1.5 h-1.5 bg-[#0B5FFF] rounded-full" />
                  {city}
                </div>
              ))}
            </div>
          </div>
          
          <div className="relative">
            <div className="aspect-square bg-white rounded-full border border-gray-200 flex items-center justify-center p-4">
              <div className="w-full h-full bg-blue-50 rounded-full flex items-center justify-center relative overflow-hidden">
                {/* Visual Representation of Phoenix Map */}
                <div className="absolute inset-0 opacity-10 flex items-center justify-center rotate-45 scale-150">
                  <div className="grid grid-cols-10 gap-2">
                    {[...Array(100)].map((_, i) => (
                      <div key={i} className="w-2 h-2 bg-blue-500 rounded-full" />
                    ))}
                  </div>
                </div>
                <div className="relative z-10 text-center">
                  <div className="w-24 h-24 bg-[#0B5FFF] text-white rounded-full flex items-center justify-center mx-auto mb-4 shadow-2xl shadow-blue-500/50">
                    <svg className="w-12 h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                    </svg>
                  </div>
                  <span className="text-xl font-bold">Phoenix HQ</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ServiceAreaMap;
