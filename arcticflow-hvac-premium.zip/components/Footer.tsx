
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-white border-t border-gray-100 pt-24 pb-12">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid md:grid-cols-4 gap-12 mb-20">
          <div className="col-span-2">
            <div className="flex items-center gap-2 mb-8">
              <div className="w-8 h-8 bg-[#0B5FFF] rounded-lg flex items-center justify-center">
                <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
              </div>
              <span className="text-xl font-bold tracking-tight text-[#0B5FFF]">ArcticFlow HVAC</span>
            </div>
            <p className="text-gray-500 max-w-sm mb-8 leading-relaxed">
              Premium cooling and heating services for the modern Arizona homeowner. Built on trust, speed, and absolute reliability.
            </p>
            <div className="flex gap-4">
              <a href="tel:6025559284" className="text-2xl font-bold hover:text-[#0B5FFF] transition-colors">(602) 555-9284</a>
            </div>
          </div>

          <div>
            <h4 className="text-xs font-bold uppercase tracking-widest text-gray-400 mb-8">Contact</h4>
            <ul className="space-y-4 font-medium">
              <li><a href="mailto:service@arcticflowhvac.com" className="hover:text-[#0B5FFF] transition-colors">service@arcticflowhvac.com</a></li>
              <li className="text-gray-500">Phoenix, Arizona</li>
              <li className="text-gray-500">24/7 Emergency Response</li>
            </ul>
          </div>

          <div>
            <h4 className="text-xs font-bold uppercase tracking-widest text-gray-400 mb-8">Status</h4>
            <ul className="space-y-4">
              <li className="flex items-center gap-2 text-green-500 font-bold">
                <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                Accepting New Calls
              </li>
              <li className="text-gray-500">Licensed: #HV-129034</li>
              <li className="text-gray-500">Insured & Bonded</li>
            </ul>
          </div>
        </div>

        <div className="flex flex-col md:flex-row justify-between items-center pt-12 border-t border-gray-100 gap-8">
          <p className="text-gray-400 text-sm">© {new Date().getFullYear()} ArcticFlow HVAC. All rights reserved.</p>
          <div className="flex gap-8 text-sm font-medium text-gray-400">
            <a href="#" className="hover:text-black">Privacy Policy</a>
            <a href="#" className="hover:text-black">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
