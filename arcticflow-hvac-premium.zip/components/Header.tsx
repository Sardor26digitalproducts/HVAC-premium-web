
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="fixed top-0 left-0 right-0 z-50 glass border-b border-gray-100">
      <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 bg-[#0B5FFF] rounded-xl flex items-center justify-center">
            <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
            </svg>
          </div>
          <span className="text-xl font-bold tracking-tight text-[#0B5FFF]">ArcticFlow</span>
        </div>
        
        <nav className="hidden md:flex items-center gap-10 text-sm font-medium text-gray-600">
          <a href="#services" className="hover:text-black transition-colors">Services</a>
          <a href="#why-us" className="hover:text-black transition-colors">Why ArcticFlow</a>
          <a href="#quote" className="hover:text-black transition-colors">Free Quote</a>
        </nav>

        <div className="flex items-center gap-4">
          <a 
            href="tel:6025559284" 
            className="hidden sm:block text-sm font-semibold text-[#0B5FFF] hover:opacity-80 transition-opacity"
          >
            (602) 555-9284
          </a>
          <a 
            href="#quote" 
            className="bg-[#0B5FFF] text-white px-6 py-2.5 rounded-full text-sm font-semibold hover:bg-blue-600 transition-all shadow-lg shadow-blue-500/20 active:scale-95"
          >
            Get Help Now
          </a>
        </div>
      </div>
    </header>
  );
};

export default Header;
