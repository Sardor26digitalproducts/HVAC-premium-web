
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality, Blob } from '@google/genai';

// Implement required encode/decode functions
function encode(bytes: Uint8Array) {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

const VoiceAssistant: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isActive, setIsActive] = useState(false);
  const [transcription, setTranscription] = useState('');
  
  const audioContextRef = useRef<AudioContext | null>(null);
  const outputAudioContextRef = useRef<AudioContext | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  const sessionRef = useRef<any>(null);

  const startSession = async () => {
    try {
      // Fix: Always use the exact apiKey from process.env.API_KEY as per guidelines
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      outputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      
      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        callbacks: {
          onopen: () => {
            setIsActive(true);
            const source = audioContextRef.current!.createMediaStreamSource(stream);
            const scriptProcessor = audioContextRef.current!.createScriptProcessor(4096, 1, 1);
            
            scriptProcessor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              const l = inputData.length;
              const int16 = new Int16Array(l);
              for (let i = 0; i < l; i++) {
                int16[i] = inputData[i] * 32768;
              }
              const pcmBlob: Blob = {
                data: encode(new Uint8Array(int16.buffer)),
                mimeType: 'audio/pcm;rate=16000',
              };
              
              // CRITICAL: Solely rely on sessionPromise resolves and then call `session.sendRealtimeInput`
              sessionPromise.then((session) => {
                session.sendRealtimeInput({ media: pcmBlob });
              });
            };
            
            source.connect(scriptProcessor);
            scriptProcessor.connect(audioContextRef.current!.destination);
          },
          onmessage: async (message: LiveServerMessage) => {
            if (message.serverContent?.outputTranscription) {
              setTranscription(prev => prev + ' ' + message.serverContent.outputTranscription!.text);
            }

            const base64Audio = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
            if (base64Audio && outputAudioContextRef.current) {
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, outputAudioContextRef.current.currentTime);
              const buffer = await decodeAudioData(decode(base64Audio), outputAudioContextRef.current, 24000, 1);
              const source = outputAudioContextRef.current.createBufferSource();
              source.buffer = buffer;
              source.connect(outputAudioContextRef.current.destination);
              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += buffer.duration;
              sourcesRef.current.add(source);
              // Fix: Use addEventListener instead of onended
              source.addEventListener('ended', () => {
                sourcesRef.current.delete(source);
              });
            }

            if (message.serverContent?.interrupted) {
              sourcesRef.current.forEach(s => s.stop());
              sourcesRef.current.clear();
              nextStartTimeRef.current = 0;
            }
          },
          onerror: (e) => console.error('Gemini Live Error:', e),
          onclose: () => setIsActive(false),
        },
        config: {
          responseModalities: [Modality.AUDIO],
          outputAudioTranscription: {},
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } },
          },
          systemInstruction: 'You are the ArcticFlow HVAC voice assistant for Phoenix, Arizona. You help customers with AC and heating inquiries. You are polite, professional, and very knowledgeable. Keep answers concise. If they need a repair, tell them a technician can be there today.',
        },
      });

      sessionRef.current = await sessionPromise;
    } catch (err) {
      console.error('Failed to start voice session:', err);
    }
  };

  const stopSession = () => {
    // Fix: Properly close the session to release resources as per guidelines
    if (sessionRef.current) {
      sessionRef.current.close();
      sessionRef.current = null;
    }
    setIsActive(false);
    if (audioContextRef.current) audioContextRef.current.close();
    if (outputAudioContextRef.current) outputAudioContextRef.current.close();
    setTranscription('');
  };

  useEffect(() => {
    if (!isOpen && isActive) stopSession();
  }, [isOpen, isActive]);

  return (
    <>
      {/* Floating CTA Pill */}
      <button 
        onClick={() => setIsOpen(true)}
        className="fixed bottom-8 right-8 z-[60] group flex items-center gap-4 bg-[#0B5FFF] text-white px-6 py-4 rounded-full shadow-2xl shadow-blue-500/40 hover:scale-105 active:scale-95 transition-all"
      >
        <div className="relative">
          <div className="absolute -inset-1 bg-white/20 rounded-full animate-ping" />
          <svg className="w-6 h-6 relative z-10" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
          </svg>
        </div>
        <span className="font-bold whitespace-nowrap">Talk to an Assistant</span>
      </button>

      {/* Assistant Modal Overlay */}
      {isOpen && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center p-6">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-md" onClick={() => setIsOpen(false)} />
          
          <div className="relative w-full max-w-lg bg-white rounded-[3rem] overflow-hidden shadow-2xl flex flex-col items-center p-12 text-center">
            <button 
              onClick={() => setIsOpen(false)}
              className="absolute top-8 right-8 text-gray-400 hover:text-black transition-colors"
            >
              <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>

            <div className="mb-12">
              <div className="w-24 h-24 bg-blue-50 rounded-full flex items-center justify-center mx-auto relative mb-6">
                {isActive ? (
                  <div className="absolute inset-0 bg-blue-500/20 rounded-full animate-pulse scale-150" />
                ) : null}
                <div className="w-16 h-16 bg-[#0B5FFF] rounded-full flex items-center justify-center text-white relative z-10 shadow-lg shadow-blue-500/30">
                  <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                  </svg>
                </div>
              </div>
              <h2 className="text-3xl font-extrabold mb-2">ArcticFlow Assistant</h2>
              <p className="text-gray-500">Ask us anything about your AC or heating.</p>
            </div>

            <div className="min-h-[100px] w-full mb-12 flex flex-col items-center justify-center">
              {isActive ? (
                <div className="space-y-4 w-full">
                  <div className="flex justify-center gap-1 h-8 items-end">
                    {[...Array(6)].map((_, i) => (
                      <div 
                        key={i} 
                        className={`w-1.5 bg-[#0B5FFF] rounded-full animate-bounce`} 
                        style={{ animationDelay: `${i * 0.1}s`, height: `${Math.random() * 100}%` }} 
                      />
                    ))}
                  </div>
                  <p className="text-gray-400 text-sm font-medium animate-pulse">Listening & Thinking...</p>
                  {transcription && (
                    <div className="p-4 bg-gray-50 rounded-2xl text-left max-h-32 overflow-y-auto">
                      <p className="text-sm text-gray-600 leading-relaxed italic">"{transcription.trim()}"</p>
                    </div>
                  )}
                </div>
              ) : (
                <button 
                  onClick={startSession}
                  className="bg-[#0B5FFF] text-white px-10 py-5 rounded-full text-xl font-bold hover:bg-blue-600 transition-all shadow-xl shadow-blue-500/30"
                >
                  Start Conversation
                </button>
              )}
            </div>

            {isActive && (
              <button 
                onClick={stopSession}
                className="text-red-500 font-bold hover:text-red-600 transition-colors"
              >
                End Call
              </button>
            )}

            <p className="mt-8 text-xs text-gray-400 font-medium">
              Powered by ArcticFlow AI. For emergencies, call <a href="tel:6025559284" className="text-[#0B5FFF] underline">(602) 555-9284</a> directly.
            </p>
          </div>
        </div>
      )}
    </>
  );
};

export default VoiceAssistant;
