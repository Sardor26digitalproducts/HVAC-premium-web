
import React from 'react';

const Testimonials: React.FC = () => {
  const reviews = [
    {
      name: "Michael R.",
      text: "ArcticFlow saved us during a 115-degree weekend. Technican arrived in 90 minutes and had the AC back up in no time. Unbeatable service.",
      rating: 5
    },
    {
      name: "Sarah Jenkins",
      text: "The most professional contractor experience I've had. Clean, polite, and very transparent about pricing. Worth every penny.",
      rating: 5
    },
    {
      name: "David T.",
      text: "They installed a new high-efficiency system. My electric bill dropped by 30% the first month. Incredible results and easy financing.",
      rating: 5
    }
  ];

  return (
    <section className="py-32 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-20">
          <h2 className="text-5xl font-extrabold tracking-tight mb-4">Trusted in Phoenix.</h2>
          <div className="flex items-center justify-center gap-2 text-[#FF7A1A]">
            {[...Array(5)].map((_, i) => (
              <svg key={i} className="w-5 h-5 fill-current" viewBox="0 0 20 20">
                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
              </svg>
            ))}
            <span className="ml-2 font-bold text-gray-900">4.9 / 5.0 (327 Reviews)</span>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-10">
          {reviews.map((review, idx) => (
            <div key={idx} className="bg-white border border-gray-100 p-12 rounded-[2.5rem] shadow-xl shadow-gray-100/50">
              <div className="mb-8">
                <div className="flex gap-1 text-[#FF7A1A]">
                  {[...Array(review.rating)].map((_, i) => (
                    <svg key={i} className="w-4 h-4 fill-current" viewBox="0 0 20 20">
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                  ))}
                </div>
              </div>
              <p className="text-xl italic text-gray-600 leading-relaxed mb-8">"{review.text}"</p>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-gray-100 rounded-full" />
                <span className="font-bold text-lg">{review.name}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
