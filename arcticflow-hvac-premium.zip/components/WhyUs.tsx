
import React from 'react';

const WhyUs: React.FC = () => {
  const benefits = [
    "Fair, upfront pricing before we start",
    "Background checked, certified pros",
    "100% satisfaction guarantee",
    "Clean workspace. No mess left behind"
  ];

  return (
    <section id="why-us" className="py-32 bg-black text-white overflow-hidden relative">
      <div className="absolute top-0 right-0 w-1/2 h-full opacity-20 pointer-events-none">
        <img 
          src="https://images.unsplash.com/photo-1581094794329-c8112a89af12?auto=format&fit=crop&q=80&w=1200" 
          alt="Technician" 
          className="w-full h-full object-cover"
        />
      </div>
      
      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="lg:w-1/2">
          <h2 className="text-5xl md:text-7xl font-extrabold leading-tight mb-12">
            Better service <br />
            by design.
          </h2>
          
          <div className="space-y-8">
            {benefits.map((benefit, idx) => (
              <div key={idx} className="flex items-start gap-6">
                <div className="mt-1 w-6 h-6 rounded-full bg-[#FF7A1A] flex items-center justify-center flex-shrink-0">
                  <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <p className="text-2xl font-light text-gray-300">{benefit}</p>
              </div>
            ))}
          </div>
          
          <div className="mt-16">
            <a href="#quote" className="inline-flex items-center gap-2 text-white text-xl font-bold hover:gap-4 transition-all">
              Start your service
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
              </svg>
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default WhyUs;
