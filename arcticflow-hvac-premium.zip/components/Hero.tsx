
import React from 'react';

const Hero: React.FC = () => {
  return (
    <section className="relative min-h-screen flex items-center pt-20 px-6 overflow-hidden">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&q=80&w=2560" 
          alt="Clean HVAC Setup" 
          className="w-full h-full object-cover grayscale-[0.3] brightness-[0.95]"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-white via-white/90 to-transparent" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto w-full grid lg:grid-cols-2 gap-12 items-center">
        <div className="max-w-2xl">
          <div className="inline-flex items-center gap-2 bg-blue-50 text-[#0B5FFF] px-4 py-2 rounded-full text-xs font-bold uppercase tracking-wider mb-8">
            <span className="w-2 h-2 bg-[#0B5FFF] rounded-full animate-pulse" />
            Same-day service in Phoenix
          </div>
          
          <h1 className="text-6xl md:text-8xl font-extrabold leading-[1.05] tracking-tight mb-8">
            HVAC Fixed <br />
            <span className="text-[#0B5FFF]">Today.</span> <br />
            Not Tomorrow.
          </h1>
          
          <p className="text-xl md:text-2xl text-gray-600 mb-10 leading-relaxed font-light">
            Certified technicians. <br />
            Fast. Reliable. Done Right.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-5 items-start sm:items-center">
            <a 
              href="tel:6025559284" 
              className="w-full sm:w-auto bg-black text-white px-10 py-5 rounded-full text-lg font-bold hover:bg-gray-800 transition-all flex items-center justify-center gap-3 shadow-2xl shadow-black/10 active:scale-95"
            >
              <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                <path d="M2 3a1 1 0 011-1h2.153a1 1 0 01.986.836l.74 4.435a1 1 0 01-.54 1.06l-1.548.773a11.037 11.037 0 006.105 6.105l.774-1.548a1 1 0 011.059-.54l4.435.74a1 1 0 01.836.986V17a1 1 0 01-1 1h-2C7.82 18 2 12.18 2 5V3z" />
              </svg>
              (602) 555-9284
            </a>
            <a 
              href="#quote" 
              className="w-full sm:w-auto bg-white text-[#0B5FFF] border-2 border-[#0B5FFF] px-10 py-5 rounded-full text-lg font-bold hover:bg-blue-50 transition-all text-center active:scale-95"
            >
              Get Free Quote
            </a>
          </div>

          <div className="mt-16 flex items-center gap-8 grayscale opacity-60">
            <img src="https://upload.wikimedia.org/wikipedia/commons/e/e1/Google_Chrome_icon_%28February_2022%29.svg" alt="Google" className="h-6" />
            <span className="h-4 w-px bg-gray-300" />
            <span className="font-bold text-gray-500 uppercase text-[10px] tracking-widest">Licensed & Insured</span>
            <span className="h-4 w-px bg-gray-300" />
            <span className="font-bold text-gray-500 uppercase text-[10px] tracking-widest">12 Years Expertise</span>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
